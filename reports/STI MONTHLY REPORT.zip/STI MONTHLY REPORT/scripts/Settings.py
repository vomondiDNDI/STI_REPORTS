
DB = {'CENTRAL_DBNAME': "pm_mf",
      'CENTRAL_USERNAME': "clinica",
      'CENTRAL_HOST': "192.168.0.250",
      'CENTRAL_PASSWD': "#Limpo@321!"
      }

#ROOT_PATH = 'F:/DATA/PLAY/testing'
ROOT_PATH = 'U:\Data Centre\Trials\MF_PM Combo\Monthly Reports\PM_MF_Report'
#ROOT_PATH = 'C:\Users\vomondi\OneDrive - Drugs for Neglected Diseases Initiative\Bureau\PmPythonscripts'

# PATHS: dictionary that holds the paths that are expected
PATHS = {'OUTPUT_FOLDER': "%s/%s/" % (ROOT_PATH, "output_folder"),
         'INPUT_FOLDER': "%s/%s/" % (ROOT_PATH, "input_folder"),
         'TEMP_FOLDER': "%s/%s/" % (ROOT_PATH, "temp")
         }